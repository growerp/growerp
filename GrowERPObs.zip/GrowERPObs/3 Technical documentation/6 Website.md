# HTML Website

The html website from the standard Moqui is used, however with major changes to make it multicompany. All changes are in the growerp branch while the master branch is a clone of the Moqui repository.

![](https://raw.githubusercontent.com/growerp/PopRestStore/growerp/README.md)