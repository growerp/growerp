# Packages
Below a number of inclusions of techinal READme's

![](https://raw.githubusercontent.com/growerp/growerp/master/packages/admin/README.md) 

![](https://raw.githubusercontent.com/growerp/growerp/master/packages/hotel)

![](https://raw.githubusercontent.com/growerp/growerp/master/packages/freelance/README.md)

![](https://raw.githubusercontent.com/growerp/growerp/master/packages/ecommerce/README.md)

![](https://raw.githubusercontent.com/growerp/growerp/master/packages/core/README.md)

![](https://raw.githubusercontent.com/growerp/growerp/master/packages/utils/README.md)
