# API
The GrowERP backend is documented in the openAPI standard:

test system at [test.growerp.org](https://test.growerp.org/toolstatic/lib/swagger-ui/index.html?url=https://test.growerp.org/rest/service.swagger/growerp#/100)

production system at [backend.growerp.com](https://backend.growerp.com/toolstatic/lib/swagger-ui/index.html?url=https://backend.growerp.com/rest/service.swagger/growerp#/100) 

[Or can be downloaded](https://test.growerp.org/rest/service.swagger/growerp) 

Currently this is an open system, an API key will be provided when you register a new company and administrator.