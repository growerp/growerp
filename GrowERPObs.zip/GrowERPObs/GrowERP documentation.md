![[growerp.png]]

The business system which runs on any platform