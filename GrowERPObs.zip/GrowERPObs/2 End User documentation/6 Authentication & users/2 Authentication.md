# Authentication 

Authentication of the backend is used. All users can login to the system as long as an email address assigned. 
