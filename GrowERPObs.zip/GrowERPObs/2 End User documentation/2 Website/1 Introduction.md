# Website Introduction

The system generates a website for every company/admin which can be viewed by using the internet address as is shown on top of the website maintenance page in the main menu company section.

This website can be used as a normal textual website where you introduce yourself or your company and provide regular information via an optional blog and can be used as a full e-commerce website where you can sell products and which can be ordered by visitors at the website.

A payment gateway is built-in. You need to provide your bank account in order to receive the ordered products on a monthly basis.

The website is maintained by the 'admin' application. on the dashboard -> company website screen. This screen will give you the internet address you an enter in the browser to show the website.

![[media/websiteAdmin.png]]  ![[media/website.png]]
