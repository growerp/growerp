You probably have your account organization already, when not just the default.

You can upload the account organization at the ledger screen in accounting

## The GL Account upload format:

id,name,isDebit,class,type,postedBalance
10000,Asset Root,true,Assets,12345.00,
11000,Cash and Equivalent Asset,true,Cash and Equivalent,Current Asset,
11100,Cash on Hand,true,Cash and Equivalent,Current Asset,
11110,General Checking Account,true,Cash and Equivalent,Current Asset,