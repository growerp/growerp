# Accounting
Accounting is mostly automatic, creating invoices/payments from orders. When approved and applied will automatically post to the ledger. 
  
## Accounts receivable

Not received payments will appear in the incoming payment list and can be confirmed by pressing the '↑' (arrow up) button on the payment.

## Accounts payable

When purchase orders are approved and invoice and payment is created which can be compared with the incoming invoice from the supplier. It can be checked in the incoming shipment list if the order is accepted by the inventory function. When yes the payment be paid by the '↑' (arrow up) button.

## Ledger
Most of the business activities are automatically posted to the ledger, of which the content can be sent to your accountant.