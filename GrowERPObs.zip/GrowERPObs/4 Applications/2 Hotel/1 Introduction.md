The hotel app is the first vertical application providing ERP system services to a specific branch, in this case a Hotel. The app provides room management, reservations and invoicing and account management.


## Overview
In general a hotel has a number of rooms in different classes or qualities with relevant pricing. So the room types define the pricing. When a reservation is entered the first free room in the requested type group is assigned to the reservation.

When the start data is the same as the today date, the reservation will appear in the 'check-in' option where when the customer arrives, the registration can be check, the room keys are handed out the up arrow can be clicked the customer has successfully checked in.

When the end data of the reservation has been reached the reservation appears in the checkout screen, where the invoice can be printed and paid, if everything OK, the up-arrow can be clicked again and the transaction will be added to the ledger.