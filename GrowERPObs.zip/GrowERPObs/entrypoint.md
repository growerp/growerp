
# entrypoint
## Test of this page
Test whether this page is the index by fetching index.html and reading whether the innerHtml of the first h1 == 'entrypoint'

## Next test
Take the first link of this page and try to open the file. Fetch the html of the file and continue.

[[Note link]]


